import { useState, useEffect } from 'react'
import { useBusiness } from '../context/BusinessContext'
import { supabase } from '../lib/supabase'
import { X } from 'lucide-react'

interface ProjectModalProps {
    onClose: () => void
    onSuccess: () => void
}

interface Customer {
    id: string
    name: string
}

export default function ProjectModal({ onClose, onSuccess }: ProjectModalProps) {
    const { activeBusiness } = useBusiness()
    const [customers, setCustomers] = useState<Customer[]>([])
    const [name, setName] = useState('')
    const [customerId, setCustomerId] = useState('')
    const [status, setStatus] = useState('active')
    const [loading, setLoading] = useState(false)

    useEffect(() => {
        if (activeBusiness) {
            supabase
                .from('customers')
                .select('id, name')
                .eq('business_id', activeBusiness.id)
                .then(({ data }) => setCustomers(data || []))
        }
    }, [activeBusiness])

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault()
        if (!activeBusiness) return
        setLoading(true)

        try {
            const { error } = await supabase
                .from('projects')
                .insert([
                    {
                        business_id: activeBusiness.id,
                        customer_id: customerId || null,
                        name,
                        status
                    }
                ])

            if (error) throw error
            onSuccess()
            onClose()
        } catch (error) {
            console.error(error)
            alert('Failed to create project')
        } finally {
            setLoading(false)
        }
    }

    return (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="bg-white p-6 rounded-xl w-full max-w-md relative card">
                <button onClick={onClose} className="absolute top-4 right-4 text-gray-500 hover:text-gray-700">
                    <X size={24} />
                </button>
                <h2 className="text-2xl font-bold mb-4">Add Project</h2>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium mb-1">Project Name</label>
                        <input
                            type="text"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            className="input"
                            required
                        />
                    </div>

                    <div>
                        <label className="block text-sm font-medium mb-1">Customer (Optional)</label>
                        <select
                            value={customerId}
                            onChange={(e) => setCustomerId(e.target.value)}
                            className="input"
                        >
                            <option value="">None</option>
                            {customers.map(c => (
                                <option key={c.id} value={c.id}>{c.name}</option>
                            ))}
                        </select>
                    </div>

                    <div>
                        <label className="block text-sm font-medium mb-1">Status</label>
                        <select
                            value={status}
                            onChange={(e) => setStatus(e.target.value)}
                            className="input"
                        >
                            <option value="active">Active</option>
                            <option value="completed">Completed</option>
                            <option value="archived">Archived</option>
                        </select>
                    </div>

                    <button type="submit" disabled={loading} className="w-full btn-primary">
                        {loading ? 'Saving...' : 'Save Project'}
                    </button>
                </form>
            </div>
        </div>
    )
}
