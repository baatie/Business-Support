import { useEffect, useState } from 'react'
import { useBusiness } from '../context/BusinessContext'
import { useAuth } from '../context/AuthContext'
import { supabase } from '../lib/supabase'
import { MOCK_EXPENSES } from '../lib/mockData'
import { Plus, Search, Filter } from 'lucide-react'
import ExpenseModal from '../components/ExpenseModal'
import { format } from 'date-fns'

interface Expense {
    id: string
    amount: number
    category: string
    date: string
    description: string
    customers: {
        name: string
    }
}

export default function Expenses() {
    const { activeBusiness } = useBusiness()
    const { isDemo } = useAuth()
    const [expenses, setExpenses] = useState<Expense[]>([])
    const [loading, setLoading] = useState(true)
    const [isModalOpen, setIsModalOpen] = useState(false)
    const [searchTerm, setSearchTerm] = useState('')
    const [filterCategory, setFilterCategory] = useState('')

    const fetchExpenses = async () => {
        if (!activeBusiness) return
        setLoading(true)

        if (isDemo) {
            // @ts-ignore
            setExpenses(MOCK_EXPENSES)
            setLoading(false)
            return
        }

        const { data, error } = await supabase
            .from('expenses')
            .select('*, customers(name)')
            .eq('business_id', activeBusiness.id)
            .order('date', { ascending: false })

        if (error) {
            console.error(error)
        } else {
            setExpenses(data || [])
        }
        setLoading(false)
    }

    useEffect(() => {
        fetchExpenses()
    }, [activeBusiness, isDemo])

    const filteredExpenses = expenses.filter(e => {
        const matchesSearch = e.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            e.category?.toLowerCase().includes(searchTerm.toLowerCase())
        const matchesCategory = filterCategory ? e.category === filterCategory : true
        return matchesSearch && matchesCategory
    })

    // Derive unique categories for filter
    const categories = Array.from(new Set(expenses.map(e => e.category)))

    return (
        <div className="p-6 max-w-7xl mx-auto animate-fade-in">
            <div className="flex justify-between items-center mb-8">
                <div>
                    <h1 className="text-3xl font-bold text-[var(--color-primary)]">Expenses</h1>
                    <p className="text-[var(--color-secondary)]">Track your spending</p>
                </div>
                <button onClick={() => setIsModalOpen(true)} className="btn-primary flex items-center gap-2">
                    <Plus size={20} /> Add Expense
                </button>
            </div>

            <div className="flex flex-col md:flex-row gap-4 mb-6">
                <div className="relative flex-1">
                    <input
                        type="text"
                        placeholder="Search expenses..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="input pl-10"
                    />
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                </div>

                <div className="relative w-full md:w-64">
                    <select
                        value={filterCategory}
                        onChange={(e) => setFilterCategory(e.target.value)}
                        className="input pl-10 appearance-none"
                    >
                        <option value="">All Categories</option>
                        {categories.map(c => (
                            <option key={c} value={c}>{c}</option>
                        ))}
                    </select>
                    <Filter className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                </div>
            </div>

            {loading ? (
                <div className="text-center py-12">Loading...</div>
            ) : (
                <div className="bg-white/80 backdrop-blur-sm rounded-xl shadow border border-[var(--color-secondary)]/20 overflow-hidden">
                    <table className="w-full text-left">
                        <thead className="bg-[var(--color-bg)]/50 border-b border-[var(--color-secondary)]/10">
                            <tr>
                                <th className="p-4 font-semibold text-[var(--color-primary)]">Date</th>
                                <th className="p-4 font-semibold text-[var(--color-primary)]">Description</th>
                                <th className="p-4 font-semibold text-[var(--color-primary)]">Category</th>
                                <th className="p-4 font-semibold text-[var(--color-primary)]">Customer</th>
                                <th className="p-4 font-semibold text-[var(--color-primary)]">Amount</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-[var(--color-secondary)]/10">
                            {filteredExpenses.map(expense => (
                                <tr key={expense.id} className="hover:bg-[var(--color-bg)]/30 transition-colors">
                                    <td className="p-4">{format(new Date(expense.date), 'MMM dd, yyyy')}</td>
                                    <td className="p-4 font-medium">{expense.description}</td>
                                    <td className="p-4">
                                        <span className="px-2 py-1 bg-gray-100 rounded-full text-xs font-medium text-gray-600">
                                            {expense.category}
                                        </span>
                                    </td>
                                    <td className="p-4">{expense.customers?.name || '-'}</td>
                                    <td className="p-4 font-medium text-red-600">
                                        -{new Intl.NumberFormat('en-US', { style: 'currency', currency: activeBusiness?.currency || 'USD' }).format(expense.amount)}
                                    </td>
                                </tr>
                            ))}
                            {filteredExpenses.length === 0 && (
                                <tr>
                                    <td colSpan={5} className="p-8 text-center opacity-50">No expenses found.</td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            )}

            {isModalOpen && (
                <ExpenseModal
                    onClose={() => setIsModalOpen(false)}
                    onSuccess={fetchExpenses}
                />
            )}
        </div>
    )
}
