import { useState, useEffect } from 'react'
import { useBusiness } from '../context/BusinessContext'
import { Save, Building, Phone, MapPin, Calendar } from 'lucide-react'

export default function Settings() {
    const { activeBusiness, updateBusiness } = useBusiness()
    const [name, setName] = useState('')
    const [address, setAddress] = useState('')
    const [phone, setPhone] = useState('')
    const [netPay, setNetPay] = useState('')
    const [theme, setTheme] = useState('')
    const [saving, setSaving] = useState(false)
    const [message, setMessage] = useState({ type: '', text: '' })

    useEffect(() => {
        if (activeBusiness) {
            setName(activeBusiness.name)
            setAddress(activeBusiness.address || '')
            setPhone(activeBusiness.phone || '')
            setNetPay(activeBusiness.net_pay_schedule || '')
            setTheme(activeBusiness.theme_preference)
        }
    }, [activeBusiness])

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault()
        if (!activeBusiness) return
        setSaving(true)
        setMessage({ type: '', text: '' })

        try {
            await updateBusiness(activeBusiness.id, {
                name,
                address,
                phone,
                net_pay_schedule: netPay,
                theme_preference: theme as any
            })
            setMessage({ type: 'success', text: 'Settings saved successfully' })
        } catch (error) {
            console.error(error)
            setMessage({ type: 'error', text: 'Failed to save settings' })
        } finally {
            setSaving(false)
        }
    }

    if (!activeBusiness) return <div className="p-8">Loading...</div>

    return (
        <div className="p-6 max-w-4xl mx-auto animate-fade-in text-[var(--color-primary)]">
            <h1 className="text-3xl font-bold mb-2">Business Settings</h1>
            <p className="text-[var(--color-secondary)] mb-8">Manage {activeBusiness.name} profile and preferences</p>

            <form onSubmit={handleSubmit} className="space-y-6">
                {/* General Info Card */}
                <div className="card">
                    <h2 className="text-xl font-bold mb-4 flex items-center gap-2 border-b border-[var(--color-secondary)]/10 pb-2">
                        <Building size={20} /> General Information
                    </h2>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                            <label className="text-sm font-medium">Business Name</label>
                            <input
                                type="text"
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                className="input"
                                required
                            />
                        </div>
                        <div className="space-y-2">
                            <label className="text-sm font-medium">Phone Number</label>
                            <div className="relative">
                                <Phone size={18} className="absolute left-3 top-1/2 -translate-y-1/2 opacity-50" />
                                <input
                                    type="text"
                                    value={phone}
                                    onChange={(e) => setPhone(e.target.value)}
                                    className="input pl-10"
                                    placeholder="(555) 123-4567"
                                />
                            </div>
                        </div>
                        <div className="space-y-2 md:col-span-2">
                            <label className="text-sm font-medium">Address</label>
                            <div className="relative">
                                <MapPin size={18} className="absolute left-3 top-3 opacity-50" />
                                <textarea
                                    value={address}
                                    onChange={(e) => setAddress(e.target.value)}
                                    className="input pl-10 min-h-[80px]"
                                    placeholder="123 Woodwork Lane..."
                                />
                            </div>
                        </div>
                    </div>
                </div>

                {/* Financial & Preferences Card */}
                <div className="card">
                    <h2 className="text-xl font-bold mb-4 flex items-center gap-2 border-b border-[var(--color-secondary)]/10 pb-2">
                        Preferences
                    </h2>

                    <div className="space-y-2">
                        <label className="text-sm font-medium">Net Pay Schedule</label>
                        <div className="relative">
                            <Calendar size={18} className="absolute left-3 top-1/2 -translate-y-1/2 opacity-50" />
                            <select
                                value={netPay}
                                onChange={(e) => setNetPay(e.target.value)}
                                className="input pl-10"
                            >
                                <option value="">Select Schedule</option>
                                <option value="Net 7">Net 7</option>
                                <option value="Net 15">Net 15</option>
                                <option value="Net 30">Net 30</option>
                                <option value="Net 60">Net 60</option>
                                <option value="Due on Receipt">Due on Receipt</option>
                            </select>
                        </div>
                    </div>
                </div>


                {
                    message.text && (
                        <div className={`p-4 rounded-lg ${message.type === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                            {message.text}
                        </div>
                    )
                }

                <div className="flex justify-end">
                    <button
                        type="submit"
                        disabled={saving}
                        className="btn-primary flex items-center gap-2 min-w-[120px] justify-center"
                    >
                        {saving ? (
                            <span className="animate-spin">⌛</span>
                        ) : (
                            <Save size={20} />
                        )}
                        Save Changes
                    </button>
                </div>
            </form >
        </div >
    )
}
