import { useEffect, useState, useRef } from 'react'
import { useBusiness } from '../context/BusinessContext'
import { useAuth } from '../context/AuthContext'
import { supabase } from '../lib/supabase'
import { MOCK_INVOICES } from '../lib/mockData'
import { Plus, Search, Printer, X } from 'lucide-react'
import InvoiceModal from '../components/InvoiceModal'
import { useReactToPrint } from 'react-to-print'
import { format } from 'date-fns'

interface Invoice {
    id: string
    invoice_number: string
    customer_id: string
    issue_date: string
    due_date: string
    total_amount: number
    status: string
    items: any[]
    customers: {
        name: string
        email: string
        address?: string
        logo_url?: string
    }
}

export default function Invoices() {
    const { activeBusiness } = useBusiness()
    const { isDemo } = useAuth()
    const [invoices, setInvoices] = useState<Invoice[]>([])
    const [loading, setLoading] = useState(true)
    const [isModalOpen, setIsModalOpen] = useState(false)
    const [searchTerm, setSearchTerm] = useState('')
    const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null)

    const printRef = useRef<HTMLDivElement>(null)

    const handlePrint = useReactToPrint({
        contentRef: printRef,
        documentTitle: `Invoice-${selectedInvoice?.invoice_number}`,
    })

    // Since useReactToPrint hooks into the ref directly, we need to ensure the ref is populated with the correct content *before* printing.
    // A simple way is to render the printable content hidden, but updating it when selectedInvoice changes.
    // Or render a modal for preview/print.

    const fetchInvoices = async () => {
        if (!activeBusiness) return
        setLoading(true)

        if (isDemo) {
            // @ts-ignore
            setInvoices(MOCK_INVOICES)
            setLoading(false)
            return
        }

        const { data, error } = await supabase
            .from('invoices')
            .select('*, customers(name, email, logo_url)')
            .eq('business_id', activeBusiness.id)
            .order('created_at', { ascending: false })

        if (error) {
            console.error(error)
        } else {
            setInvoices(data || [])
        }
        setLoading(false)
    }

    useEffect(() => {
        fetchInvoices()
    }, [activeBusiness, isDemo])

    useEffect(() => {
        if (selectedInvoice && printRef.current?.innerHTML) {
            // Verify content is rendered before printing? 
            // Actually useReactToPrint handles this if we call handlePrint from a user action.
            // We will open a "Preview" modal and then print from there.
        }
    }, [selectedInvoice])


    const filteredInvoices = invoices.filter(i =>
        i.invoice_number?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        i.customers?.name?.toLowerCase().includes(searchTerm.toLowerCase())
    )

    return (
        <div className="p-6 max-w-7xl mx-auto animate-fade-in">
            <div className="flex justify-between items-center mb-8">
                <div>
                    <h1 className="text-3xl font-bold text-[var(--color-primary)]">Invoices</h1>
                    <p className="text-[var(--color-secondary)]">Manage billing and payments</p>
                </div>
                <button onClick={() => setIsModalOpen(true)} className="btn-primary flex items-center gap-2">
                    <Plus size={20} /> Create Invoice
                </button>
            </div>

            <div className="mb-6 relative">
                <input
                    type="text"
                    placeholder="Search invoices..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="input pl-10"
                />
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
            </div>

            {loading ? (
                <div className="text-center py-12">Loading...</div>
            ) : (
                <div className="bg-white/80 backdrop-blur-sm rounded-xl shadow border border-[var(--color-secondary)]/20 overflow-hidden">
                    <table className="w-full text-left">
                        <thead className="bg-[var(--color-bg)]/50 border-b border-[var(--color-secondary)]/10">
                            <tr>
                                <th className="p-4 font-semibold text-[var(--color-primary)]">Invoice #</th>
                                <th className="p-4 font-semibold text-[var(--color-primary)]">Customer</th>
                                <th className="p-4 font-semibold text-[var(--color-primary)]">Date</th>
                                <th className="p-4 font-semibold text-[var(--color-primary)]">Due Date</th>
                                <th className="p-4 font-semibold text-[var(--color-primary)]">Amount</th>
                                <th className="p-4 font-semibold text-[var(--color-primary)]">Status</th>
                                <th className="p-4 font-semibold text-[var(--color-primary)]">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-[var(--color-secondary)]/10">
                            {filteredInvoices.map(invoice => (
                                <tr key={invoice.id} className="hover:bg-[var(--color-bg)]/30 transition-colors">
                                    <td className="p-4 font-medium">{invoice.invoice_number}</td>
                                    <td className="p-4">{invoice.customers?.name}</td>
                                    <td className="p-4">{format(new Date(invoice.issue_date), 'MMM dd, yyyy')}</td>
                                    <td className="p-4">{format(new Date(invoice.due_date), 'MMM dd, yyyy')}</td>
                                    <td className="p-4 font-medium">
                                        {new Intl.NumberFormat('en-US', { style: 'currency', currency: activeBusiness?.currency || 'USD' }).format(invoice.total_amount)}
                                    </td>
                                    <td className="p-4">
                                        <span className={`px-2 py-1 rounded-full text-xs font-medium uppercase
                      ${invoice.status === 'paid' ? 'bg-green-100 text-green-700' :
                                                invoice.status === 'overdue' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'}`}>
                                            {invoice.status}
                                        </span>
                                    </td>
                                    <td className="p-4">
                                        <button
                                            onClick={() => {
                                                setSelectedInvoice(invoice);
                                                // Small delay to allow render then print could be tricky, 
                                                // better to show a preview dialog then print.
                                            }}
                                            className="p-2 text-[var(--color-secondary)] hover:text-[var(--color-primary)]"
                                            title="Print/Preview"
                                        >
                                            <Printer size={18} />
                                        </button>
                                    </td>
                                </tr>
                            ))}
                            {filteredInvoices.length === 0 && (
                                <tr>
                                    <td colSpan={7} className="p-8 text-center opacity-50">No invoices found.</td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            )}

            {isModalOpen && (
                <InvoiceModal
                    onClose={() => setIsModalOpen(false)}
                    onSuccess={fetchInvoices}
                />
            )}

            {/* Invoice Print Preview / Hidden Render */}
            {selectedInvoice && (
                <div className="fixed inset-0 bg-black/80 z-[60] flex items-center justify-center p-4">
                    <div className="bg-white w-full max-w-4xl h-[90vh] flex flex-col rounded-xl overflow-hidden">
                        <div className="p-4 border-b flex justify-between items-center bg-gray-50">
                            <h3 className="font-bold">Proview Invoice</h3>
                            <div className="flex gap-2">
                                <button onClick={() => handlePrint()} className="btn-primary flex items-center gap-2">
                                    <Printer size={16} /> Print / Save PDF
                                </button>
                                <button onClick={() => setSelectedInvoice(null)} className="p-2 hover:bg-gray-200 rounded">
                                    <X size={20} />
                                </button>
                            </div>
                        </div>

                        <div className="flex-1 overflow-auto bg-gray-100 p-8">
                            {/* The actual printable content */}
                            <div ref={printRef} className="bg-white shadow-lg p-12 max-w-[210mm] mx-auto min-h-[297mm] text-black">
                                <div className="flex justify-between items-start mb-12">
                                    <div>
                                        <h1 className="text-4xl font-bold text-gray-800 mb-2">{activeBusiness?.name}</h1>
                                        <p className="text-gray-500">Invoice #{selectedInvoice.invoice_number}</p>
                                        <p className="text-gray-500">Status: <span className="uppercase">{selectedInvoice.status}</span></p>
                                    </div>
                                    <div className="text-right">
                                        {selectedInvoice.customers?.logo_url ? (
                                            <img src={selectedInvoice.customers.logo_url} alt="Logo" className="h-16 object-contain mb-2 ml-auto" />
                                        ) : (
                                            <div className="h-16 w-16 bg-gray-200 rounded ml-auto flex items-center justify-center text-xs">No Logo</div>
                                        )}
                                    </div>
                                </div>

                                <div className="grid grid-cols-2 gap-8 mb-12">
                                    <div>
                                        <h4 className="font-bold text-gray-600 mb-2">Bill To:</h4>
                                        <p className="font-bold text-lg">{selectedInvoice.customers?.name}</p>
                                        <p>{selectedInvoice.customers?.email}</p>
                                        <p>{selectedInvoice.customers?.address || ''}</p>
                                    </div>
                                    <div className="text-right">
                                        <div className="mb-2">
                                            <span className="text-gray-600">Issue Date:</span>
                                            <span className="font-medium ml-2">{format(new Date(selectedInvoice.issue_date), 'MMM dd, yyyy')}</span>
                                        </div>
                                        <div>
                                            <span className="text-gray-600">Due Date:</span>
                                            <span className="font-bold ml-2 text-red-600">{format(new Date(selectedInvoice.due_date), 'MMM dd, yyyy')}</span>
                                        </div>
                                    </div>
                                </div>

                                <table className="w-full mb-8">
                                    <thead>
                                        <tr className="border-b-2 border-gray-800">
                                            <th className="text-left py-3 font-bold">Description</th>
                                            <th className="text-right py-3 font-bold">Qty</th>
                                            <th className="text-right py-3 font-bold">Price</th>
                                            <th className="text-right py-3 font-bold">Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {selectedInvoice.items?.map((item: any, i: number) => (
                                            <tr key={i} className="border-b border-gray-200">
                                                <td className="py-3">{item.description}</td>
                                                <td className="py-3 text-right">{item.quantity}</td>
                                                <td className="py-3 text-right">${Number(item.price).toFixed(2)}</td>
                                                <td className="py-3 text-right">${(item.quantity * item.price).toFixed(2)}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>

                                <div className="flex justify-end">
                                    <div className="w-1/3 border-t border-gray-300 pt-4">
                                        <div className="flex justify-between mb-2">
                                            <span>Subtotal:</span>
                                            <span>${selectedInvoice.total_amount.toFixed(2)}</span>
                                        </div>
                                        <div className="flex justify-between font-bold text-xl border-t border-gray-800 pt-2">
                                            <span>Total:</span>
                                            <span>${selectedInvoice.total_amount.toFixed(2)}</span>
                                        </div>
                                    </div>
                                </div>

                                <div className="mt-16 pt-8 border-t border-gray-200 text-center text-gray-500 text-sm">
                                    <p>Thank you for your business!</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    )
}
